#!/bin/env bash

set -e

# ------------------------------------------------------------
# Limpeza
# ------------------------------------------------------------

rm -f labplot grafico.dat plot_config.dat

# ------------------------------------------------------------
# Compilação EXCLUSIVA para plot
# ------------------------------------------------------------

make dplot >/dev/null

# ------------------------------------------------------------
# Execução
# ------------------------------------------------------------

./labplot 1024

# ------------------------------------------------------------
# Verifica arquivos gerados
# ------------------------------------------------------------

if [[ ! -f grafico.dat ]]; then
    echo
    echo "ERRO: grafico.dat não foi gerado."
    exit 1
fi

if [[ ! -f plot_config.dat ]]; then
    echo
    echo "ERRO: plot_config.dat não foi gerado."
    exit 1
fi

# ------------------------------------------------------------
# Lê a configuração realmente usada pelo programa C
# ------------------------------------------------------------

read -r K EXP < plot_config.dat

# ------------------------------------------------------------
# Gnuplot - solução analítica
# ------------------------------------------------------------

gnuplot -persist << EOF
K = $K
EXP = $EXP
pi = 3.141592653589793

set xlabel "x"
set ylabel "y"
set zlabel "u(x,y)"

set palette defined ( \
-1.0 "#2166ac", \
-0.5 "#67a9cf", \
 0.0 "#f7f7f7", \
 0.5 "#ef8a62", \
 1.0 "#b2182b" )

set autoscale cb
set autoscale z

set samples 500
set isosamples 500

set grid
set pm3d
set hidden3d

set xrange [0:1]
set yrange [0:1]

S(t) = sum [j=1 : EXP] sin ((K**j)*pi*t)
f(x,y) = S(x)*S(y)

splot \
    f(x,y) with pm3d title "Analítica"
EOF

# ------------------------------------------------------------
# Gnuplot - solução numérica
# ------------------------------------------------------------

gnuplot -persist << EOF
set palette defined ( \
-1.0 "#2166ac", \
-0.5 "#67a9cf", \
 0.0 "#f7f7f7", \
 0.5 "#ef8a62", \
 1.0 "#b2182b" )

set autoscale cb
set autoscale z

set xlabel "x"
set ylabel "y"
set zlabel "u(x,y)"

splot "grafico.dat" u 1:2:3 with pm3d title "Numérica"
EOF

# ------------------------------------------------------------
# Gnuplot - erro absoluto
# ------------------------------------------------------------

gnuplot -persist << EOF
set palette defined ( \
0.00 "#001F7A", \
0.15 "#0057B8", \
0.30 "#00A6D6", \
0.45 "#F3E55B", \
0.60 "#F5A623", \
0.75 "#F5A623", \
0.90 "#E53935", \
1.00 "#7F0000" )

set view map
set pm3d map
set size ratio -1
set format cb "%.2e"

set logscale cb

stats "grafico.dat" u 4 nooutput
erro_max = STATS_max

set xlabel "x"
set ylabel "y"
set cblabel "erro absoluto"

set cbtics add (sprintf("%.2e", erro_max) erro_max)

splot "grafico.dat" u 1:2:4 with pm3d title "Erro absoluto"
EOF

# ------------------------------------------------------------
# Limpeza final
# ------------------------------------------------------------

rm -f grafico.dat plot_config.dat
