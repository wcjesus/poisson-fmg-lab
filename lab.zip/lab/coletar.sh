#!/usr/bin/env bash
# Colete 50 combinacoes A/B/C por execucao do LAB original.
# Nao altera os fontes originais: compila copia temporaria dos fontes.
set -Eeuo pipefail
export LC_ALL=C

origem="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
for item in Makefile config.mk configuracao.h lab.c; do
    [[ -f "$origem/$item" ]] || { echo "Erro: coloque este .sh na pasta lab/ (falta $item)." >&2; exit 1; }
done
for programa in make gcc awk sed sha256sum; do
    command -v "$programa" >/dev/null || { echo "Falta comando: $programa" >&2; exit 1; }
done

perguntar_natural() {
    local pergunta="$1" valor
    while true; do
        read -r -p "$pergunta" valor || { echo "Entrada encerrada." >&2; exit 1; }
        if [[ "$valor" =~ ^[0-9]+$ ]] && (( ${#valor} <= 9 )) && (( 10#$valor >= 1 )); then
            RESPOSTA=$((10#$valor))
            return
        fi
        echo "Informe um inteiro positivo."
    done
}

perguntar_sim_nao() {
    local pergunta="$1" valor
    while true; do
        read -r -p "$pergunta" valor || { echo "Entrada encerrada." >&2; exit 1; }
        case "${valor,,}" in
            s|sim) RESPOSTA=s; return ;;
            n|nao|não|'') RESPOSTA=n; return ;;
            *) echo "Digite s ou n." ;;
        esac
    done
}

perguntar_natural "Malha MAIS FINA (N2, por exemplo 32, 64, 128): "
malha_fina="$RESPOSTA"
if (( malha_fina > 2000000000 || malha_fina % 2 != 0 )); then
    echo "Malha fina invalida: deve ser par e caber no tipo int." >&2; exit 1
fi
malha_entrada=$((malha_fina / 2))
n_tmp="$malha_entrada"
while (( n_tmp > 16 )) && (( n_tmp % 2 == 0 )); do n_tmp=$((n_tmp / 2)); done
if (( n_tmp != 16 )); then
    echo "Malha invalida. O lab aceita N1=16*2^k e N2=2*N1; portanto N2=32,64,128,..." >&2
    exit 1
fi
perguntar_natural "Quantas EXECUCOES COMPLETAS deseja realizar (recomendado >= 5)? "
repeticoes="$RESPOSTA"
perguntar_sim_nao "Deseja PERSONALIZAR os macros? [s/N; N=usar padrao sem alterar]: "
personalizar="$RESPOSTA"

lote="$(date -u +'%Y%m%dT%H%M%SZ')_$$"
saida_dir="$origem/resultados_lab"
mkdir -p "$saida_dir"
tabela="$saida_dir/lab_${lote}.txt"
logs_dir="$saida_dir/logs_${lote}"
mkdir -p "$logs_dir"
diretorio_tmp="$(mktemp -d "${TMPDIR:-/tmp}/lab_coleta.XXXXXX")"
cleanup() {
    if [[ -n "${diretorio_tmp:-}" && -d "$diretorio_tmp" ]]; then
        rm -rf -- "$diretorio_tmp"
    fi
}
trap cleanup EXIT
cp -- "$origem"/*.c "$origem"/*.h "$origem/Makefile" "$origem/config.mk" "$diretorio_tmp/"
header="$diretorio_tmp/configuracao.h"

atualizar_macro() {
    local chave="$1" tipo="$2" atual novo valido=0
    atual="$(awk -v chave="$chave" '$1 == "#define" && $2 == chave {print $3; exit}' "$header")"
    [[ -n "$atual" ]] || { echo "Macro $chave nao encontrada." >&2; exit 1; }
    while true; do
        read -r -p "  $chave [$atual] (Enter mantem): " novo || exit 1
        [[ -z "$novo" ]] && return 0
        valido=0
        if [[ "$tipo" == int_pos ]] && [[ "$novo" =~ ^[0-9]+$ ]] && (( ${#novo} <= 9 )) && (( 10#$novo >= 1 )); then valido=1; fi
        if [[ "$tipo" == int_nneg ]] && [[ "$novo" =~ ^[0-9]+$ ]] && (( ${#novo} <= 9 )); then valido=1; fi
        if [[ "$tipo" == real_pos ]] && [[ "$novo" =~ ^([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][-+]?[0-9]+)?$ ]] \
          && awk -v x="$novo" 'BEGIN {exit !(x > 0 && x < 1e100)}'; then valido=1; fi
        if (( valido )); then
            # Entrada validada: apenas literais numericos, sem injecao de sed/codigo.
            sed -E -i "s@^(#define[[:space:]]+$chave[[:space:]]+).*@\\1$novo@" "$header"
            return 0
        fi
        echo "  Valor invalido para $chave. Use numero decimal com ponto (ex.: 1e-7)."
    done
}

if [[ "$personalizar" == s ]]; then
    echo "Personalizando configuracao.h na COPIA temporaria (sem editar o original)."
    atualizar_macro K real_pos
    atualizar_macro EXP int_pos
    atualizar_macro OMEGA real_pos
    atualizar_macro OMEGAGS real_pos
    atualizar_macro NU1 int_nneg
    atualizar_macro NU2 int_nneg
    atualizar_macro MAX_ITER_GROSSO int_pos
    atualizar_macro MAX_CICLOS int_pos
    atualizar_macro TOLERANCIA_C real_pos
    atualizar_macro TOLERANCIA_B real_pos
    atualizar_macro T real_pos
    # NUM e usado na linha informativa N1 da saida antiga, nao define N1 real.
    atualizar_macro NUM int_pos
fi
config_id="$(sha256sum "$header" | awk '{print substr($1,1,16)}')"
{
    echo "lote=$lote"
    echo "config_id=$config_id"
    echo "malha_fina=$malha_fina"
    echo "malha_entrada=$malha_entrada"
    echo "repeticoes=$repeticoes"
    echo "macros_personalizadas=$personalizar"
    echo "Observacao: em lab.c, o campo informativo N1 pode vir do macro NUM; o argumento real da execucao e $malha_entrada."
    echo "--- configuracao.h compilada ---"
    cat "$header"
} > "$saida_dir/lab_${lote}.config.txt"

printf 'lote\tconfig_id\texecucao\tmalha_fina\tmalha_entrada\tA\tB\tC\tp\tVcyc\tt_cic_ms\ttPre_ms\ttPos_ms\tNcoar\tt_s\n' > "$tabela"
echo "Compilando copia isolada do lab (-B evita usar objetos antigos)..."
if ! make -B -C "$diretorio_tmp" lab > "$saida_dir/lab_${lote}.compilacao.log" 2>&1; then
    echo "Falha na compilacao. Confira: $saida_dir/lab_${lote}.compilacao.log" >&2
    exit 1
fi

for ((execucao=1; execucao<=repeticoes; execucao++)); do
    printf 'Execucao %d/%d: ./lab %d 0 ...\n' "$execucao" "$repeticoes" "$malha_entrada"
    log="$logs_dir/exec_$(printf '%04d' "$execucao").log"
    if ! (cd "$diretorio_tmp" && ./lab "$malha_entrada" 0) > "$log" 2>&1; then
        echo "Falha na execucao $execucao; veja $log. Dados incompletos nao serao adicionados." >&2
        exit 1
    fi
    temporario_linhas="$logs_dir/.parcial_${execucao}.tsv"
    if ! awk -v lote="$lote" -v cfg="$config_id" -v rodada="$execucao" -v fina="$malha_fina" -v entrada="$malha_entrada" '
    /OVERVIEW FINAL/ {dentro=1; next}
    dentro && /^\|/ {
        n=split($0, col, "|")
        if (n != 12) next
        for (i=2; i<=11; i++) gsub(/^[[:space:]]+|[[:space:]]+$/, "", col[i])
        if (col[2] != "Jacobi" && col[2] != "Gauss-Seidel") next
        if (col[3] != "LU" && col[3] != "LDL" && col[3] != "Gauss-Jordan" && col[3] != "Jacobi" && col[3] != "Gauss-Seidel") next
        if (col[4] != "LU" && col[4] != "LDL" && col[4] != "Gauss-Jordan" && col[4] != "Jacobi" && col[4] != "Gauss-Seidel") next
        numerico="^[-+]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][-+]?[0-9]+)?$"
        for (i=5; i<=11; i++) if (col[i] !~ numerico) {erro=1; printf "Campo numerico invalido: %s\n", col[i] > "/dev/stderr"; exit 2}
        if (col[6] !~ /^[0-9]+$/ || col[10] !~ /^[0-9]+$/) {erro=1; exit 2}
        chave=col[2] SUBSEP col[3] SUBSEP col[4]
        if (visto[chave]++) {erro=1; printf "Combinacao duplicada\n" > "/dev/stderr"; exit 2}
        printf "%s\t%s\t%d\t%d\t%d\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", lote,cfg,rodada,fina,entrada,col[2],col[3],col[4],col[5],col[6],col[7],col[8],col[9],col[10],col[11]
        total++
    }
    END {if (!erro && total != 50) {printf "Esperadas 50 linhas do OVERVIEW FINAL, encontradas %d\n", total > "/dev/stderr"; exit 3}}
    ' "$log" > "$temporario_linhas"; then
        rm -f "$temporario_linhas"
        echo "Falha ao extrair OVERVIEW FINAL da execucao $execucao. Log: $log" >&2
        exit 1
    fi
    cat "$temporario_linhas" >> "$tabela"
    rm -f "$temporario_linhas"
done
printf '\nColeta finalizada: %d linhas de dados (%d execucoes x 50 combinacoes).\n' "$((repeticoes*50))" "$repeticoes"
echo "Envie este arquivo ao Colab: $tabela"
echo "Metadados/macros: $saida_dir/lab_${lote}.config.txt"
echo "Logs integrais: $logs_dir"
