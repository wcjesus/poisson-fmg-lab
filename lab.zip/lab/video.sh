#!/usr/bin/env bash
# Video 3D do FMG: solucoes parciais, convergencia e comparacao analitica.
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

n="${1:-64}"
if [[ ! "$n" =~ ^[0-9]+$ ]] || (( ${#n} > 9 )); then
    echo 'Erro: informe VIDEO_N=16,32,64,128,...' >&2
    exit 1
fi
n=$((10#$n))
valor="$n"
while (( valor > 16 && valor % 2 == 0 )); do valor=$((valor / 2)); done
if (( valor != 16 )); then
    echo 'Erro: a malha deve ser N=16*2^k (16,32,64,128,...).' >&2
    exit 1
fi

for comando in make gnuplot ffmpeg; do
    if ! command -v "$comando" >/dev/null 2>&1; then
        echo "Erro: instale $comando para usar make video." >&2
        exit 1
    fi
done
if [[ "${VIDEO_NO_PLAY:-0}" != 1 ]] && ! command -v ffplay >/dev/null 2>&1; then
    echo 'Erro: instale ffplay ou use VIDEO_NO_PLAY=1.' >&2
    exit 1
fi

# Nao substituir um diretorio antigo que nao foi criado por esta execucao.
if [[ -e quadros || -e video_dados ]]; then
    echo 'Erro: quadros/ ou video_dados/ ja existe. Guarde ou remova manualmente.' >&2
    exit 1
fi

limpar() {
    rm -rf -- quadros video_dados
    rm -f -- labvideo ./*.video.o
}
trap limpar EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

make -s labvideo
mkdir -- quadros video_dados
printf '\nVideo 3D, malha %s: escolha padroes e metodos A/B/C.\n' "$n"
./labvideo "$n" 1

indice='video_dados/quadros.tsv'
if [[ ! -s "$indice" || ! -s video_dados/escala.txt ]]; then
    echo 'Erro: o solver nao gerou os dados para o video.' >&2
    exit 1
fi
altura=$(cat video_dados/escala.txt)
roteiro='video_dados/render.gnuplot'
cat > "$roteiro" <<EOF
set terminal pngcairo size 1600,900 enhanced font 'DejaVu Sans,15'
set encoding utf8
set view 63,38,1.0,1.0
set pm3d depthorder
set palette defined (-1.0 '#2166ac', -0.5 '#67a9cf', 0.0 '#f7f7f7', 0.5 '#ef8a62', 1.0 '#b2182b')
set xrange [0:1]
set yrange [0:1]
set zrange [-$altura:$altura]
set cbrange [-$altura:$altura]
set xyplane at -$altura
set xlabel 'x'
set ylabel 'y'
set zlabel 'v(x,y)'
set grid
set ticslevel 0
set border 4095
unset key
set colorbox
EOF

quadro=0
ultimo=''
while IFS=$'\t' read -r id etapa malha ciclo residuo; do
    arquivo="video_dados/quadro_${id}.dat"
    [[ -s "$arquivo" ]] || { echo "Falta $arquivo" >&2; exit 1; }
    case "$etapa" in
        C)           titulo="C resolvido, malha ${malha}x${malha}" ;;
        interpolacao) titulo="Interpolacao: ${malha}x${malha}" ;;
        FMG)         titulo="FMG apos V-cycle: ${malha}x${malha}" ;;
        chute_FMG)   titulo="Aproximacao inicial FMG: ${malha}x${malha}" ;;
        ciclo)       titulo="V-cycle ${ciclo} - residuo ${residuo}" ;;
        final)       titulo="Solucao final - ${ciclo} ciclos, residuo ${residuo}" ;;
        *)           echo "Etapa desconhecida: $etapa" >&2; exit 1 ;;
    esac
    destino=$(printf 'quadros/quadro_%06d.png' "$quadro")
    cat >> "$roteiro" <<EOF
set output '$destino'
set title '$titulo'
splot '$arquivo' using 1:2:3 with pm3d
unset output
EOF
    ultimo="$arquivo"
    quadro=$((quadro + 1))
done < "$indice"

[[ -n "$ultimo" ]] || { echo 'Nenhum quadro registrado.' >&2; exit 1; }
analitica=$(printf 'quadros/quadro_%06d.png' "$quadro")
cat >> "$roteiro" <<EOF
set output '$analitica'
set title 'Solucao analitica - superficie em R^3'
splot '$ultimo' using 1:2:4 with pm3d
unset output
EOF
quadro=$((quadro + 1))
comparacao=$(printf 'quadros/quadro_%06d.png' "$quadro")
cat >> "$roteiro" <<EOF
set terminal pngcairo size 1920,900 enhanced font 'DejaVu Sans,14'
set output '$comparacao'
stats '$ultimo' using 5 nooutput
max_erro = (STATS_max > 0 ? STATS_max : 1e-16)
set multiplot layout 1,3 title 'Comparacao final - mesma perspectiva 3D'
set zlabel 'u(x,y)'
set title 'Solucao numerica'
splot '$ultimo' using 1:2:3 with pm3d
set title 'Solucao analitica'
splot '$ultimo' using 1:2:4 with pm3d
set zrange [0:max_erro]
set cbrange [0:max_erro]
set xyplane at 0
set zlabel '|numerica - analitica|'
set title 'Erro absoluto'
splot '$ultimo' using 1:2:5 with pm3d
unset multiplot
unset output
EOF

echo "Gerando $((quadro + 1)) quadros 3D com gnuplot..."
gnuplot "$roteiro"

# Prolonga a exibicao da comparacao, sem recalcular a solucao.
for ((a=1; a<=14; a++)); do
    quadro=$((quadro + 1))
    cp -- "$comparacao" "$(printf 'quadros/quadro_%06d.png' "$quadro")"
done

ffmpeg -y -hide_banner -loglevel error -framerate 6 \
    -i 'quadros/quadro_%06d.png' -c:v libx264 -pix_fmt yuv420p \
    -vf 'scale=1920:900:force_original_aspect_ratio=decrease,pad=1920:900:(ow-iw)/2:(oh-ih)/2' \
    -movflags +faststart video.mp4

echo 'Video criado: video.mp4'
if [[ "${VIDEO_NO_PLAY:-0}" != 1 ]]; then
    echo 'Abrindo ffplay em loop infinito; feche a janela para finalizar a limpeza.'
    ffplay -loglevel warning -loop 0 -vf "setpts=2*PTS" video.mp4
fi
