#!/usr/bin/env bash

set -e
aqui=$(pwd -P)
dir=$(basename "$aqui")
zipfile="$aqui/$dir.zip"

(
	cd ..

	zip -r "$zipfile" "$dir" -x "$dir.zip/$dir.zip"
	
)
