# Cole esta celula no Google Colab (Python 3). Requer pandas e numpy.
# Cada arquivo .txt enviado deve vir de coletar_lab.sh.
from io import BytesIO
from pathlib import Path
import math
import numpy as np
import pandas as pd
from IPython.display import display

# Limiares EXPLORATORIOS, editaveis (nao sao testes de significancia).
LIMITE_VERDE = 5.0          # CV < 5%
LIMITE_VERMELHO = 15.0      # CV >= 15%
N_MINIMO = 5               # abaixo disso, nao dar verde
Z_ROBUSTO = 3.5            # limiar para outlier (MAD modificado)
DESVIO_REL_OUTLIER = 0.20  # tambem exige desvio relativo >= 20%
RESOLUCAO_TCIC_MS = 0.0001 # impressao: quatro casas decimais em ms
RESOLUCAO_T_S = 0.001      # impressao: tres casas decimais em s

COLUNAS_NUMERICAS = ["p", "Vcyc", "t_cic_ms", "tPre_ms", "tPos_ms", "Ncoar", "t_s"]
CHAVES = ["config_id", "malha_fina", "A", "B", "C"]
ESPERADAS = {"lote", "config_id", "execucao", "malha_fina", "malha_entrada", "A", "B", "C", *COLUNAS_NUMERICAS}


def pedir_sim_nao(pergunta):
    try:
        return input(pergunta + " [s/N]: ").strip().lower() in ("s", "sim")
    except EOFError:
        return False


def carregar_arquivos():
    try:
        from google.colab import files
        arquivos = files.upload()  # selecione SOMENTE os .txt tabulados
        if not arquivos:
            return None
        partes = [(nome, BytesIO(conteudo)) for nome, conteudo in arquivos.items()]
    except ImportError:
        caminhos = input("Caminhos dos .txt, separados por virgula: ").strip().split(",")
        partes = [(p.strip(), p.strip()) for p in caminhos if p.strip()]
        if not partes:
            return None

    resultado = []
    for nome, arquivo in partes:
        tabela = pd.read_csv(arquivo, sep="\t", encoding="utf-8", dtype={"lote": str, "config_id": str})
        ausentes = ESPERADAS - set(tabela.columns)
        if ausentes:
            raise ValueError(f"{nome}: nao e um arquivo gerado pelo coletor. Faltam: {sorted(ausentes)}")
        tabela = tabela[list(ESPERADAS)].copy()
        for c in COLUNAS_NUMERICAS + ["execucao", "malha_fina", "malha_entrada"]:
            tabela[c] = pd.to_numeric(tabela[c], errors="raise")
            if not np.isfinite(tabela[c].to_numpy(dtype=float)).all():
                raise ValueError(f"{nome}: ha valores numericos invalidos em {c}.")
        resultado.append(tabela)
    return pd.concat(resultado, ignore_index=True)


def validar(dados):
    # Evita contar uploads repetidos como novas observacoes.
    chave_linha = ["lote", "config_id", "malha_fina", "execucao", "A", "B", "C"]
    duplicadas = dados.duplicated(subset=chave_linha)
    if duplicadas.any():
        print(f"Aviso: {duplicadas.sum()} linhas repetidas do mesmo lote foram ignoradas.")
        dados = dados.loc[~duplicadas].copy()
    lotes = dados.groupby(["lote", "config_id", "malha_fina", "execucao"]).size()
    if (lotes != 50).any():
        raise ValueError("Alguma execucao nao possui exatamente 50 combinacoes. Verifique os arquivos.")
    combos = dados.groupby(["lote", "config_id", "malha_fina", "execucao"])[["A", "B", "C"]].apply(
        lambda t: len(t.drop_duplicates()))
    if (combos != 50).any():
        raise ValueError("Ha combinacoes A/B/C repetidas ou faltantes.")
    return dados


def estatisticas(dados):
    agrupado = dados.groupby(CHAVES, sort=True, dropna=False)
    tabela = agrupado.size().rename("n").to_frame()
    for metrica in COLUNAS_NUMERICAS:
        g = agrupado[metrica]
        media = g.mean()
        desvio = g.std(ddof=1)  # DESVIO PADRAO AMOSTRAL
        tabela[f"{metrica}_media"] = media
        tabela[f"{metrica}_mediana"] = g.median()
        tabela[f"{metrica}_desvio_amostral"] = desvio
        tabela[f"{metrica}_CV_pct"] = np.where(media.abs() > 1e-12, 100 * desvio / media.abs(), np.nan)

    tabela["p_amplitude"] = agrupado["p"].max() - agrupado["p"].min()
    tabela["Vcyc_variou"] = agrupado["Vcyc"].nunique() > 1
    tabela["Ncoar_variou"] = agrupado["Ncoar"].nunique() > 1

    def semaforo(linha):
        cv = linha["t_cic_ms_CV_pct"]
        media = linha["t_cic_ms_media"]
        if linha["p_amplitude"] > 0.02 or linha["Vcyc_variou"] or linha["Ncoar_variou"]:
            return "VERMELHO (numerico)"
        if np.isfinite(cv) and cv >= LIMITE_VERMELHO:
            return "VERMELHO"
        if linha["n"] < N_MINIMO or not np.isfinite(cv) or media < 20 * RESOLUCAO_TCIC_MS:
            return "AMARELO (inconclusivo)"
        if cv >= LIMITE_VERDE:
            return "AMARELO"
        return "VERDE"

    tabela["sinal"] = tabela.apply(semaforo, axis=1)
    return tabela.reset_index()


def candidatos_outliers(dados):
    # Somente tempos de ciclo; removemos a LINHA inteira se o usuario decidir excluir.
    # Para n pequeno e MAD=0, apenas desvios grandes sao sinalizados.
    indices = []
    for _, fatia in dados.groupby(CHAVES, sort=False):
        if len(fatia) < N_MINIMO:
            continue
        valores = fatia["t_cic_ms"].to_numpy(dtype=float)
        mediana = np.median(valores)
        mad = np.median(np.abs(valores - mediana))
        if mad > 0:
            z = 0.6745 * np.abs(valores - mediana) / mad
        else:
            z = np.where(np.abs(valores - mediana) > 0, np.inf, 0)
        dist = np.abs(valores - mediana)
        limiar = max(5 * RESOLUCAO_TCIC_MS, DESVIO_REL_OUTLIER * max(abs(mediana), RESOLUCAO_TCIC_MS))
        mascara = (z > Z_ROBUSTO) & (dist >= limiar)
        # Se sao varios valores suspeitos, pode ser instabilidade real. Nao descartar.
        if 0 < mascara.sum() < max(2, math.ceil(len(fatia) * 0.20)):
            indices.extend(fatia.index[mascara].tolist())
    return sorted(set(indices))


def mostrar(dados, titulo):
    resumo = estatisticas(dados)
    print("\n" + "=" * 90)
    print(titulo)
    print(f"Linhas: {len(dados)} | Lotes: {dados.lote.nunique()} | Execucoes distintas: "
          f"{dados[['lote', 'execucao']].drop_duplicates().shape[0]}")
    print("SINAIS:")
    print(resumo["sinal"].value_counts().to_string())
    frac_vermelho = resumo["sinal"].str.startswith("VERMELHO").mean()
    if frac_vermelho >= 0.30:
        print("ALERTA SISTEMICO: 30% ou mais das combinacoes estao VERMELHAS. "
              "Nao parece razoavel explicar tudo por um unico valor anormal.")
    colunas = CHAVES + ["n", "p_media", "p_mediana", "Vcyc_media", "t_cic_ms_media",
                         "t_cic_ms_mediana", "t_cic_ms_desvio_amostral", "t_cic_ms_CV_pct",
                         "t_s_media", "t_s_mediana", "sinal"]
    with pd.option_context("display.max_rows", 100, "display.max_columns", None,
                           "display.width", 200, "display.float_format", "{:,.4f}".format):
        display(resumo[colunas])
    return resumo


def salvar(resumo, nome):
    # Overview completo: media, mediana, DP amostral e CV de TODAS as metricas.
    destino = Path(nome)
    resumo.to_csv(destino, index=False, sep=";", encoding="utf-8-sig", float_format="%.10g")
    print(f"Overview completo salvo: {destino}")
    print("Nota: t_s e exibido pelo C com resolucao de 0,001 s; em tempos curtos, "
          "seu CV pode ser dominado por arredondamento. O semaforo usa t_cic_ms.")


def persistencia_entre_lotes(dados):
    if dados.lote.nunique() < 2:
        return
    por_lote = estatisticas_por_lote(dados)
    ruins = por_lote[por_lote["sinal"].str.startswith("VERMELHO")]
    contagem = ruins.groupby(CHAVES)["lote"].nunique()
    recorrentes = contagem[contagem >= 2]
    if len(recorrentes):
        print(f"\nALERTA: {len(recorrentes)} configuracoes ficaram VERMELHAS em 2 ou mais lotes "
              "separados. Nao atribua o resultado a uma unica medicao anormal.")
        print("Verifique concorrencia de processos, aquecimento, afinidade da CPU, "
              "resolucao dos cronometros e criterios de parada do solver.")
    else:
        print("\nNao houve configuracoes VERMELHAS em dois lotes distintos "
              "com os dados atuais. Isso nao comprova estabilidade.")


def estatisticas_por_lote(dados):
    partes = []
    for lote, fatia in dados.groupby("lote"):
        r = estatisticas(fatia)
        r.insert(0, "lote", lote)
        partes.append(r)
    return pd.concat(partes, ignore_index=True)


def principal():
    print("Envie apenas o(s) arquivo(s) lab_*.txt gerado(s) por coletar_lab.sh.")
    dados = carregar_arquivos()
    if dados is None:
        print("Nenhum arquivo recebido.")
        return
    dados = validar(dados)
    inicial = mostrar(dados, "OVERVIEW ORIGINAL (nenhum outlier descartado)")
    salvar(inicial, "overview_lab_original.csv")
    suspeitos = candidatos_outliers(dados)

    if suspeitos:
        print(f"\nHa {len(suspeitos)} observacoes CANDIDATAS a outlier "
              "(heuristica MAD, com diferenca relativa minima de 20%).")
        display(dados.loc[suspeitos, ["lote", "execucao", "A", "B", "C", "t_cic_ms"]].head(40))
        if pedir_sim_nao("Deseja avaliar tambem um cenario SEM esses valores? Original sera preservado"):
            filtrados = dados.drop(index=suspeitos)
            revisado = mostrar(filtrados, "OVERVIEW DE SENSIBILIDADE (outliers excluidos)")
            salvar(revisado, "overview_lab_sem_outliers.csv")
            ainda_ruins = revisado[revisado.sinal.str.startswith("VERMELHO")]
            if not ainda_ruins.empty:
                print("ATENCAO: persistem configuracoes VERMELHAS mesmo depois das exclusoes.")
            else:
                print("Melhora ao excluir valores nao prova que eles eram erros: "
                      "registre exclusoes e repita o experimento.")
    else:
        print("\nNenhum outlier isolado foi detectado (ou ha menos de 5 repeticoes).")

    if inicial.sinal.str.startswith("VERMELHO").any() or inicial.sinal.str.startswith("AMARELO").any():
        print("\nSe quiser conferir a estabilidade, execute novamente coletar_lab.sh na "
              "SUA maquina com a MESMA malha e macros; depois suba o NOVO .txt.")
        if pedir_sim_nao("Deseja importar agora uma segunda bateria para comparar?"):
            novos = carregar_arquivos()
            if novos is not None:
                dados = validar(pd.concat([dados, novos], ignore_index=True))
                atualizado = mostrar(dados, "OVERVIEW COM TODAS AS BATERIAS (SEM exclusoes)")
                salvar(atualizado, "overview_lab_reteste.csv")
                persistencia_entre_lotes(dados)
                if atualizado.sinal.str.startswith("VERMELHO").any():
                    print("ALERTA FINAL: ainda existe variabilidade excessiva "
                          "ou inconsistencia numerica. Nao atribua tudo a um outlier isolado.")
    print("\nCriterios exploratorios: VERDE CV<5%; AMARELO 5%-<15%; VERMELHO >=15%; "
          "exige ao menos 5 repeticoes para VERDE. DP com ddof=1; CV=100*DP/|media|.")
    print("Nao descarte observacoes sem justificativa experimental documentada.")


if __name__ == "__main__":
    principal()
