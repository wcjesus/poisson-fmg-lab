#!/usr/bin/env bash

set -e

MAKEFILE="Makefile"

# Guarda o Makefile original para poder restaurá-lo exatamente.
backup=$(mktemp)
cp "$MAKEFILE" "$backup"

# Mesmo que alguma etapa dê erro, restaura o Makefile
# e tenta limpar os arquivos da compilação.
cleanup()
{
    status=$?

    rm -f *.o labprof >/dev/null 2>&1 || true

    cp "$backup" "$MAKEFILE"
    rm -f "$backup"

    trap - EXIT
    exit "$status"
}

trap cleanup EXIT

# Adiciona -pg a EXTRA_FLAGS.
if grep -q '^[[:space:]]*EXTRA_CFLAGS[[:space:]]*=' "$MAKEFILE"; then
    sed -i \
        '/^[[:space:]]*EXTRA_CFLAGS[[:space:]]*=/ s/[[:space:]]*$/ -pg/' \
        "$MAKEFILE"
else
    echo "Erro: EXTRA_CCFLAGS não encontrado no Makefile."
    exit 1
fi


# Se uma malha foi fornecida, usa ela.
# Caso contrário, escolhe o padrão de acordo com a dimensão.
if [ -n "${1:-}" ]; then
    N="$1"
else
    N=16
fi

echo "Profiling: $DIMENSAO, malha = $N"

make gprof

./labprof "$N" 0

gprof labprof gmon.out > profile.txt

cat profile.txt
