#!/usr/bin/env bash

set -euo pipefail

# ============================================================
# Diretório em que ESTE script está.
# Não depende do diretório de onde o usuário chamou o script.
# ============================================================

ATUAL="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
PAI="$(dirname -- "$ATUAL")"
AVO="$(dirname -- "$PAI")"


# ============================================================
# Remove TODAS as variações de Multigrid existentes diretamente
# dentro de um diretório.
#
# Exemplos removidos:
#
# Multigrid
# multigrid
# MULTIGRID
# Multigrid.zip
# Multigrid(1).zip
# Multigrid (1).zip
# Multigrid (1)
# Multigrid (1) (1)
# Multigrid_old
# Multigrid.qualquer-coisa
#
# Pode ser arquivo, diretório ou link.
#
# O segundo argumento, quando fornecido, é PRESERVADO.
# ============================================================

limpar_multigrid()
{
    local BASE="$1"
    local PRESERVAR="${2:-}"

    while IFS= read -r -d '' ITEM; do

        # Nunca apaga o objeto que estamos usando como origem.
        if [ -n "$PRESERVAR" ] && [ "$ITEM" = "$PRESERVAR" ]; then
            continue
        fi

        rm -rf -- "$ITEM"

    done < <(
        find "$BASE" \
            -mindepth 1 \
            -maxdepth 1 \
            -iname 'lab*' \
            -print0
    )
}


# ============================================================
# PRIMEIRA LIMPEZA
#
# Antes de verificar se PAI contém somente ATUAL, eliminamos
# todos os Multigrid* concorrentes.
#
# Isso é importante para casos como:
#
# Multigrid (1)/
# Multigrid/ <- ATUAL
# Multigrid.zip
#
# Depois da limpeza sobra somente ATUAL, portanto o diretório
# intermediário pode desaparecer.
# ============================================================

limpar_multigrid "$PAI" "$ATUAL"


# ============================================================
# Verifica se, depois da limpeza, o pai contém SOMENTE ATUAL.
# ============================================================

PAI_SO_TEM_ATUAL=true

while IFS= read -r -d '' ITEM; do
    if [ "$ITEM" != "$ATUAL" ]; then
        PAI_SO_TEM_ATUAL=false
        break
    fi
done < <(
    find "$PAI" \
        -mindepth 1 \
        -maxdepth 1 \
        -print0
)


if $PAI_SO_TEM_ATUAL; then

    # ========================================================
    # CASO 1
    #
    # Estrutura como:
    #
    # algum-lugar/
    # Multigrid.zip
    # Multigrid (1)/
    # Multigrid/
    #
    # Queremos terminar com:
    #
    # algum-lugar/
    # Multigrid/
    #
    # Ou seja:
    # - apagar os outros Multigrid*
    # - retirar ATUAL do diretório intermediário
    # - apagar o diretório intermediário
    # - chamar ATUAL definitivamente de Multigrid
    # ========================================================

    DESTINO="$AVO/lab"

    # Remove tudo Multigrid* no avô, inclusive ZIPs,
    # mas preserva o PAI porque ATUAL ainda está dentro dele.
    limpar_multigrid "$AVO" "$PAI"


    # Nome temporário propositalmente NÃO começa com Multigrid,
    # para nunca ser atingido pela rotina de limpeza.
    TMP="$AVO/.normalizando-mg.$$.$RANDOM"

    if [ -e "$TMP" ] || [ -L "$TMP" ]; then
        echo "Erro: caminho temporário já existe:"
        echo " $TMP"
        exit 1
    fi


    # Tira ATUAL de dentro do wrapper.
    mv -- "$ATUAL" "$TMP"


    # Como verificamos anteriormente que não havia mais nada
    # dentro de PAI, ele agora deve estar realmente vazio.
    rmdir -- "$PAI"


    # Por segurança, faz uma nova limpeza antes do nome final.
    limpar_multigrid "$AVO"


    # Coloca o projeto no lugar definitivo.
    mv -- "$TMP" "$DESTINO"


    # Garantia final:
    # DESTINO será o único Multigrid* existente nesse nível.
    limpar_multigrid "$AVO" "$DESTINO"


else

    # ========================================================
    # CASO 2
    #
    # O pai contém outros arquivos/diretórios que NÃO são
    # Multigrid*. Portanto não podemos apagar o pai.
    #
    # Ficamos nesse nível e apenas transformamos ATUAL em:
    #
    # Multigrid
    #
    # apagando qualquer outro Multigrid* concorrente.
    # ========================================================

    DESTINO="$PAI/lab"


    # A primeira limpeza já eliminou os Multigrid* concorrentes,
    # mas repetimos aqui para deixar a operação autocontida.
    limpar_multigrid "$PAI" "$ATUAL"


    # Renomeia ATUAL para o nome definitivo.
    if [ "$ATUAL" != "$DESTINO" ]; then
        mv -- "$ATUAL" "$DESTINO"
    fi


    # Garantia final:
    # não sobra Multigrid.zip, Multigrid(1).zip,
    # Multigrid (2), multigrid-old etc.
    limpar_multigrid "$PAI" "$DESTINO"

fi
